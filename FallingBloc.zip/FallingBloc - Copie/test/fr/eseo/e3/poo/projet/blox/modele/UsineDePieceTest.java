package fr.eseo.e3.poo.projet.blox.modele;

import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;

public class UsineDePieceTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
