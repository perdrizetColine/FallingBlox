package fr.eseo.e3.poo.projet.blox.modele;

public enum Couleur {
	ROUGE,
	ORANGE,
	BLEU,
	VERT,
	JAUNE,
	CYAN,
	VIOLET
}
