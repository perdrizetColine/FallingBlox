package fr.eseo.e3.poo.projet.blox.controleur;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;

import fr.eseo.e3.poo.projet.blox.modele.Coordonnees;
import fr.eseo.e3.poo.projet.blox.modele.Couleur;
import fr.eseo.e3.poo.projet.blox.modele.pieces.IPiece;

public class PieceRotationTest {

	@Test
	void test1() {
		IPiece ip = new IPiece(new Coordonnees(2,6),Couleur.ROUGE);
		System.out.println(ip.toString());
		ip.tourner(false);
		System.out.println(ip.toString());
		ip.tourner(false);
		System.out.println(ip.toString());
		ip.tourner(false);
		System.out.println(ip.toString());
		ip.tourner(false);
		System.out.println(ip.toString());

	}

}
