package fr.eseo.e3.poo.projet.blox.modele.pieces;


import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import fr.eseo.e3.poo.projet.blox.modele.Coordonnees;
import fr.eseo.e3.poo.projet.blox.modele.Couleur;

public class IPieceTest {

	@Test 
	void testConstructeur() {
		Coordonnees coord = new Coordonnees(6,5);
		Couleur couleur = Couleur.ROUGE;
		IPiece iPiece = new IPiece(coord, couleur);
		
		assertEquals(Couleur.ROUGE,iPiece.getElements().get(0).getCouleur(),"couleur 1");
		assertEquals(Couleur.ROUGE,iPiece.getElements().get(1).getCouleur(),"couleur 2");
		assertEquals(Couleur.ROUGE,iPiece.getElements().get(2).getCouleur(),"couleur 3");
		assertEquals(Couleur.ROUGE,iPiece.getElements().get(3).getCouleur(),"couleur 4");
		
		assertEquals(coord,iPiece.getElements().get(0).getCoordonnees(),"coordonnes 1");
		assertEquals(new Coordonnees(6,6),iPiece.getElements().get(1).getCoordonnees(),"coordonnes 2");
		assertEquals(new Coordonnees(6,3),iPiece.getElements().get(2).getCoordonnees(),"coordonnes 2");
		assertEquals(new Coordonnees(6,4),iPiece.getElements().get(3).getCoordonnees(),"coordonnes 2");
	}
	
	@Test
	void testToString() {
		Coordonnees coord = new Coordonnees(6,5);
		Couleur couleur = Couleur.CYAN;
		IPiece iPiece = new IPiece(coord, couleur);
		String stringAttendu = "IPiece :\n	(6, 5) - CYAN\n	(6, 6) - CYAN\n	(6, 3) - CYAN\n	(6, 4) - CYAN\n";
		assertEquals(stringAttendu,iPiece.toString(),"to string");
	}

}
