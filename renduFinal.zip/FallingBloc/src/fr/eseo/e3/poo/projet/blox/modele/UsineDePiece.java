package fr.eseo.e3.poo.projet.blox.modele;

import fr.eseo.e3.poo.projet.blox.modele.pieces.IPiece;
import fr.eseo.e3.poo.projet.blox.modele.pieces.OPiece;
import fr.eseo.e3.poo.projet.blox.modele.pieces.Piece;
import java.util.Random;

public class UsineDePiece {
	
	//attributs
	public static final int ALEATOIRE_COMPLET =0;
	public static final int ALEATOIRE_PIECE = 2;
	public static final int CYCLIC = 1;
	public static int modeDeFonctionnement;
	public static int cycle = 0;
	
	//Constructeur
	private UsineDePiece() {
	}
	
	//setter
	public static void setMode(int mode) {
		switch(mode) {
		case 0:
			modeDeFonctionnement = ALEATOIRE_COMPLET;
			break;
		case 1:
			modeDeFonctionnement = CYCLIC;
			break;
		default :
			modeDeFonctionnement = ALEATOIRE_PIECE;
			break;
		}
	}
	
	//méthode
	public static Piece genererPiece() {
		Coordonnees coord = new Coordonnees (2,3);
		Random random = new Random();
		Piece piece = null;
		int aleacomplet = random.nextInt(10);
		switch(modeDeFonctionnement) {
		case CYCLIC :
			if (cycle == 0) {
				cycle = 1;
				piece= new OPiece(coord, Couleur.ROUGE);
			}else if (cycle == 1) {
				cycle = 0;
				piece = new IPiece(coord, Couleur.ORANGE);
			}
			
			//piece = cycle == 0 ? new OPiece(coord, Couleur.ROUGE) : new IPiece(coord, Couleur.ORANGE);
			break;
			
		case ALEATOIRE_COMPLET :
			if (aleacomplet%2 == 0) {
				piece = new OPiece(coord, Couleur.ROUGE);
			}else {
				piece = new IPiece(coord, Couleur.ORANGE);
			}
			break;
		case ALEATOIRE_PIECE:
			if (aleacomplet%2 == 0) {
				piece = new OPiece(coord, Couleur.ROUGE);
			}else {
				piece = new IPiece(coord, Couleur.ORANGE);
			}
			break;
		}
		return piece;
	}
}